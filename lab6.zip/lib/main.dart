import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
void main() {
  runApp(NOVAApp());
}
class NOVAApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'NOVA Control Lab',
      home: HomeScreen(),
    );
  }
}